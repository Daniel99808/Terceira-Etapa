export class Modal {
    constructor(modalSelector, closeSelector, formsSelector, blurSelector, localStorageKey = 'modalShown') {
        this.modal = document.querySelector(modalSelector);
        this.closeButton = document.querySelector(closeSelector);
        this.forms = document.querySelector(formsSelector);
        this.blurElement = document.querySelector(blurSelector);
        this.localStorageKey = localStorageKey;
        this.init();
    }

    init() {
        if (this.modal) {
            if (!this.hasModalBeenShown()) {
                this.showModal();
            }
            this.addCloseListeners();
        }
        return this;
    }

    hasModalBeenShown() {
        return localStorage.getItem(this.localStorageKey) === 'true';
    }

    showModal() {
        if (this.modal) {
            this.modal.classList.add('active');
            if (this.blurElement) {
                this.blurElement.classList.add('blur');
            }
        }
    }

    closeModal() {
        if (this.modal) {
            this.modal.classList.remove('active');
            if (this.blurElement) {
                this.blurElement.classList.remove('blur');
            }
            localStorage.setItem(this.localStorageKey, 'true');
        }
    }

    addCloseListeners() {
        if (this.closeButton) {
            this.closeButton.addEventListener('click', () => this.closeModal());
        }
    }
}