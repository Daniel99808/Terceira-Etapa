export default function accordionInit() {
    const faqTitles = document.querySelectorAll('.js-accordion dt');
    const faqContents = document.querySelectorAll('.js-accordion dd');

    faqTitles.forEach((title, index) => {
        title.addEventListener('click', () => {
            faqTitles.forEach(t => {
                if (t !== title) {
                    t.classList.remove('active');
                }
            });
            faqContents.forEach(content => {
                if (content !== faqContents[index]) {
                    content.classList.remove('active');
                }
            });
            title.classList.toggle('active');
            faqContents[index].classList.toggle('active');
        });
    });

    faqContents.forEach(content => content.classList.remove('active'));
    faqTitles.forEach(title => title.classList.remove('active'));
}