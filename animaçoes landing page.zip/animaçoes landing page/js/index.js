import accordionInit from "./modules/accordion.js";
import tabMenuInit from "./modules/tabmenu.js";
import menuMobileInit from "./modules/menuMobile.js";
import { Modal } from "./modules/modal.js";

tabMenuInit();
accordionInit();
menuMobileInit();

document.addEventListener('DOMContentLoaded', () => {
    const myModal = new Modal('.modal.js-modal', '.modal-close', '.modal-forms', '.js-modal-blur');
});